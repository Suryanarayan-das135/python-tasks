from tkinter import *

root=Tk()
root.geometry("500x500")
root.title("Calculaotr")

#Entry box
e=Entry(root,width=50,borderwidth=5,font=("",18))
e.place(x=0,y=0)

# All functions

def click(num):
    result=e.get()
    e.delete(0,END)
    e.insert(0,str(result)+str(num))

#buttons

#row=0

def clear():
    e.delete(0,END)
    
b0=Button(root,text="Clear",width=10,borderwidth=3,command=lambda:clear())
b0.place(x=5,y=50)

def expo():
    n1=e.get()
    global math
    math ="exponential"
    global i
    i=float (n1)
    e.delete(0,END)

b0=Button(root,text="**",width=10,borderwidth=3,command=lambda:expo())
b0.place(x=90,y=50)

def percentile():
    n1=e.get()
    global math
    math ="Percentile"
    global i
    i=float (n1)
    e.delete(0,END)

b0=Button(root,text="%",width=10,borderwidth=3,command=lambda:percentile())
b0.place(x=175,y=50)

def div():
    n1=e.get()
    global math
    math ="division"
    global i
    i=float (n1)
    e.delete(0,END)

b0=Button(root,text="/",width=10,borderwidth=3,command=lambda:div())
b0.place(x=260,y=50)

#row=1

b1=Button(root,text="1",width=10,borderwidth=3,command=lambda:click(1))
b1.place(x=5,y=90)

b1=Button(root,text="2",width=10,borderwidth=3,command=lambda:click(2))
b1.place(x=90,y=90)

b1=Button(root,text="3",width=10,borderwidth=3,command=lambda:click(3))
b1.place(x=175,y=90)

def mult():
    n1=e.get()
    global math
    math ="Multiplication"
    global i
    i=float (n1)
    e.delete(0,END)

b1=Button(root,text="*",width=10,borderwidth=3,command=lambda:mult())
b1.place(x=260,y=90)

#row=2

b2=Button(root,text="4",width=10,borderwidth=3,command=lambda:click(4))
b2.place(x=5,y=130)

b2=Button(root,text="5",width=10,borderwidth=3,command=lambda:click(5))
b2.place(x=90,y=130)

b2=Button(root,text="6",width=10,borderwidth=3,command=lambda:click(6))
b2.place(x=175,y=130)

def sub():
    n1=e.get()
    global math
    math ="substraction"
    global i
    i=float (n1)
    e.delete(0,END)

b2=Button(root,text="-",width=10,borderwidth=3,command=lambda:sub())
b2.place(x=260,y=130)

#row=3

b3=Button(root,text="7",width=10,borderwidth=3,command=lambda:click(7))
b3.place(x=5,y=170)

b3=Button(root,text="8",width=10,borderwidth=3,command=lambda:click(8))
b3.place(x=90,y=170)

b3=Button(root,text="9",width=10,borderwidth=3,command=lambda:click(9))
b3.place(x=175,y=170)

def add():
    n1=e.get()
    global math
    math ="Addition"
    global i
    i=float (n1)
    e.delete(0,END)

b3=Button(root,text="+",width=10,borderwidth=3,command=lambda :add())
b3.place(x=260,y=170)

#row=4

b4=Button(root,text="0",width=22,borderwidth=3,command=lambda:click(0))
b4.place(x=5,y=210)

def dot():
    n1=e.get()
    global i
    i=float (n1)

b4=Button(root,text=".",width=10,borderwidth=3,command=lambda:click("."))
b4.place(x=175,y=210)

def equal():
    n2=e.get()
    e.delete(0,END)
    
    if math =="Addition":
        e.insert(0,i+int(n2))

    elif math =="substraction":
        e.insert(0,i-int(n2))

    elif math =="Multiplication":
        e.insert(0,i*int(n2))

    elif math =="division":
        e.insert(0,i/int(n2))

    elif math =="exponential":
        e.insert(0,i**int(n2))

    elif math =="Percentile":
        e.insert(0,i%int(n2))

b4=Button(root,text="=",width=10,borderwidth=3,command=lambda:equal())
b4.place(x=260,y=210)


mainloop()